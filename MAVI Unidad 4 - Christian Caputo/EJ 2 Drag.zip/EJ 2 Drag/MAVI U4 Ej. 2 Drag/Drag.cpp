#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
using namespace sf;
using namespace std;

Texture texture;
Sprite sprites[4];

int index;
float Xpos;
float Ypos;
bool dragging;

int main()
{
	texture.loadFromFile("rcircle.png");
	
	for (int i = 0; i < 4; i++)
	{
		sprites[i].setTexture(texture);
		sprites[i].setOrigin(64, 64);
	}

	sprites[0].setPosition(64, 64);
	sprites[1].setPosition(736, 64);
	sprites[2].setPosition(64, 536);
	sprites[3].setPosition(736, 536);

	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Sniper");

	while (App.isOpen())
	{
		sf::Vector2i mousePos = sf::Mouse::getPosition(App);

		Event evt;
		while (App.pollEvent(evt))
		{
			switch (evt.type)
			{
				case sf::Event::Closed:
					App.close();
					break;

				case sf::Event::MouseButtonPressed:
					for(int i = 0; i<4; i++)
					{
						sf::Vector2f spritePos = sprites[i].getPosition();
						// Comparo la posici�n del mouse con la de cada sprite dentro de sus dimensiones
						if (((mousePos.x > (spritePos.x - 64)) && (mousePos.x < (spritePos.x + 64))) &&
							((mousePos.y > (spritePos.y - 64)) && (mousePos.y < (spritePos.y + 64))))
						{
							index = i;
							dragging = true;
							break;
						}
					}
					break;

				case sf::Event::MouseButtonReleased:
					dragging = false;
					break;
			}

			if(dragging)
			{
				sprites[index].setPosition(mousePos.x, mousePos.y);
			}

			if (sf::Keyboard::isKeyPressed(Keyboard::Escape) == true)
			{
				App.close();
			}
		}
		
		App.clear();
		for (int i = 0; i < 4; i++)
		{
			App.draw(sprites[i]);
		}
		App.display();
	}

	return 0;
}