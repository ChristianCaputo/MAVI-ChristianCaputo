#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture crosshairTexture;
Sprite crosshairSprite;

int main()
{
	crosshairTexture.loadFromFile("crosshair.png");
	crosshairSprite.setTexture(crosshairTexture);
	crosshairSprite.setOrigin(64 , 64);
	crosshairSprite.setScale(0.3, 0.3);
	crosshairSprite.setPosition(400, 300);

	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Crosshair");

	while (App.isOpen())
	{
		Event evt;
		while (App.pollEvent(evt))
		{
			switch (evt.type)
			{
				case sf::Event::Closed:
					App.close();
					break;
			}

			if (sf::Keyboard::isKeyPressed(Keyboard::Escape) == true)
			{
				App.close();
			}
		}

		App.clear();
		App.draw(crosshairSprite);
		App.display();
	}

	return 0;
}