#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture redCircleText;
Texture blueCircleText;
Sprite sprites[100];

int main()
{
	redCircleText.loadFromFile("rcircle.png");
	blueCircleText.loadFromFile("rcircleb.png");
	int i=0;

	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Splats");

	while (App.isOpen())
	{
		sf::Vector2i mousePos = sf::Mouse::getPosition(App);
		
		Event evt;
		while (App.pollEvent(evt))
		{
			switch (evt.type)
			{
				case sf::Event::Closed:
					App.close();
					break;
			
				case sf::Event::MouseButtonPressed:

					if (evt.mouseButton.button == sf::Mouse::Left)
					{
						sprites[i].setTexture(redCircleText);
						sprites[i].setOrigin(64, 64);
						sprites[i].setPosition(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));
					}
					if (evt.mouseButton.button == sf::Mouse::Right)
					{
						sprites[i].setTexture(blueCircleText);
						sprites[i].setOrigin(64, 64);
						sprites[i].setPosition(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));
					}
					i++;
					break;
			}
		}

		App.clear();
		for (int i = 0; i < 100; i++)
		{
			App.draw(sprites[i]);
		}
		App.display();
	}

	return 0;
}