#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture cuadText;
Texture circleText;
Sprite sprite;

float Xpos;
float Ypos;

int main()
{
	cuadText.loadFromFile("cuad_yellow.png");
	circleText.loadFromFile("rcircle.png");
	
	sprite.setOrigin(256, 256);
	sprite.setTexture(cuadText);
	sprite.setScale(0.19, 0.19);

	Xpos = 400;
	Ypos = 300;
	sprite.setPosition(Xpos,Ypos);

	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Atrapado");

	while (App.isOpen())
	{
		Event evt;
		while (App.pollEvent(evt))
		{
			switch (evt.type)
			{
				case sf::Event::Closed:
				
					App.close();
					break;

				case sf::Event::KeyPressed:
					switch (evt.key.code)
					{
						case sf::Keyboard::Right:
							if(Xpos < 750)
							{
								sprite.setPosition(Xpos + 15, Ypos);
								Xpos += 10;
							}
							break;

						case sf::Keyboard::Left:
							if (Xpos > 50)
							{ 
								sprite.setPosition(Xpos - 15, Ypos);
								Xpos -= 10;
							}
							break;

						case sf::Keyboard::Up:
							if(Ypos > 50)
							{ 
								sprite.setPosition(Xpos, Ypos - 15);
								Ypos -= 10;
							}
							break;

						case sf::Keyboard::Down:
							if (Ypos < 550)
							{ 
								sprite.setPosition(Xpos, Ypos + 15);
								Ypos += 10; 
							}
							break;

						case sf::Keyboard::Space:
							sprite.setTexture(circleText);
							sprite.setOrigin(64, 64);
							sprite.setScale(0.78, 0.78);

							break;
					}
			}

			if (Keyboard::isKeyPressed(sf::Keyboard::Escape)==true)
			{
				App.close();
			}
		}
		
		App.clear();
		App.draw(sprite);
		App.display();
	}

	return 0;
}