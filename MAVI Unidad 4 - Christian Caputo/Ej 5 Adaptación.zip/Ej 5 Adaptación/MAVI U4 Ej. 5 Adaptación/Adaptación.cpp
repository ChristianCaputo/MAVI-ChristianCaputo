#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
using namespace std;
using namespace sf;

int main()
{
	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Adaptaci�n");

		while(App.isOpen())
		{
			Event evt;
			while (App.pollEvent(evt))
			{
				switch (evt.type)
				{
					case::sf::Event::Closed:
						App.close();
						break;

					case::sf::Event::Resized:
						sf::Vector2u winSize = App.getSize();
						if (winSize.x < 100)
						{
							winSize.x = 100;
						}
						if (winSize.y < 100)
						{
							winSize.y = 100;
						}
						if (winSize.x > 1000)
						{
							winSize.x = 1000;
						}
						if (winSize.y > 1000)
						{
							winSize.y = 1000;
						}
						App.setSize(winSize);
						break;
				}
			}

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape) == true)
			{
				App.close();
			}

			App.clear();
			App.display();
		}

	return 0;
}