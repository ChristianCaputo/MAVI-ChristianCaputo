#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include "Enemigo.h";
#include "Crosshair.h";

using namespace sf;
using namespace std;

Crosshair _crosshair;
Enemigo enemigos[5];
int enemigosMuertos;

int main()
{
	srand(time(NULL));
	
	sf::RenderWindow App(VideoMode(800, 600, 32), "Clickale");
	App.setMouseCursorVisible(false);

	while (App.isOpen())
	{
		sf::Vector2i mousePos = sf::Mouse::getPosition(App);
		
		Event evt;
		while (App.pollEvent(evt))
		{
			switch (evt.type)
			{
				case sf::Event::Closed:
					App.close();
					break;

				case sf::Event::MouseMoved:
					_crosshair.crosshairSprite.setPosition(evt.mouseMove.x, evt.mouseMove.y);
					break;

				case sf::Event::MouseButtonPressed:
					for(int i =0; i<5; i++)
					{	// Comparo posici�n del mouse con la de los enemigos
						if (((mousePos.x > (enemigos[i].etSprite.getPosition().x - 30)) && 
							(mousePos.x < (enemigos[i].etSprite.getPosition().x + 30))) &&
							((mousePos.y > (enemigos[i].etSprite.getPosition().y - 30)) && 
							(mousePos.y < (enemigos[i].etSprite.getPosition().y + 30))))
						{
							cout << "KILL!";
							enemigos[i].Muerto();
							enemigos[i].Desaparecer();
							enemigosMuertos++;
							if (enemigosMuertos >= 5)
							{
								App.close();
							}
						}
					}
					break;
			}
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape) == true)
		{
			App.close();
		}

		for (int i = 0; i < 5; i++)
		{
			enemigos[i].Timer();
		}

		App.clear();
		for(int i=0; i<5; i++)
		{ 
			App.draw(enemigos[i].etSprite);
		}
		App.draw(_crosshair.crosshairSprite);
		App.display();
	}

	return 0;
}

