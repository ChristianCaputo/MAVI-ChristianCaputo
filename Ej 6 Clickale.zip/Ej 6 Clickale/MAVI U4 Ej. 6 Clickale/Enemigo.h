#include <iostream>
#include <SFML/Graphics.hpp>
#include <ctime>
using namespace sf;
using namespace std;

class Enemigo {
private:
	Texture enemyTexture;
	sf::Clock _clock;
	float tiempo_visible;
	float tiempo_invisible;
	bool _visible;
	bool muerto;

public:
	Sprite etSprite;
	Enemigo();
	void Aparecer();
	void Desaparecer();
	void Timer();
	void Muerto();
};
