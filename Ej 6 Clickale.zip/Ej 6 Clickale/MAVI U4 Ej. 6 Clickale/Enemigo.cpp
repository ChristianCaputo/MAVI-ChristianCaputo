#include <iostream>
#include <SFML/Graphics.hpp>
#include <chrono>
#include <thread>
#include "Enemigo.h";

using namespace sf;
using namespace std;

Enemigo::Enemigo()
{
	float x = static_cast<float>(rand() % 8 + 1);
	float y = static_cast<float>(rand()%6 + 1);
	
	int Xpos = (int)x*90;
	int Ypos = (int)y*90;

	enemyTexture.loadFromFile("et.png");
	etSprite.setTexture(enemyTexture);

	etSprite.setOrigin(818.15, 810.5);
	etSprite.setPosition(Xpos, Ypos);
	etSprite.setScale(0.06, 0.06);

	tiempo_visible = rand() % 3 + 0;
	tiempo_invisible = 0.5f;
	_visible = true;
	muerto = false;
}

void Enemigo::Timer()
{
	if (_clock.getElapsedTime().asSeconds() > tiempo_visible)
	{
		Desaparecer();
	}
	if (_clock.getElapsedTime().asSeconds() > tiempo_invisible)
	{
		Aparecer();
	}
}

void Enemigo::Aparecer()
{
	if (_visible == false && muerto == false)
	{
		float x = static_cast<float>(rand() % 8 + 1);
		float y = static_cast<float>(rand() % 6 + 1);

		int Xpos = (int)x * 90;
		int Ypos = (int)y * 90;
		etSprite.setScale(0.06, 0.06);
		etSprite.setPosition(Xpos, Ypos);
		_visible = true;
		_clock.restart();
	}
}

void Enemigo::Desaparecer() 
{
	if(_visible==true)
	{
		etSprite.setScale(0.0001, 0.0001);
		_visible = false;
		_clock.restart();
	}
}

void Enemigo::Muerto()
{
	muerto = true;
}






