#include <iostream>
#include <SFML/Graphics.hpp>
#include <ctime>
using namespace sf;
using namespace std;

class Crosshair {
private:
	Texture texture;

public:
	Sprite crosshairSprite;
	Crosshair();
};