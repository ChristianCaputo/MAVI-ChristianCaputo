#include <iostream>
#include <SFML/Graphics.hpp>
#include <ctime>
#include "Crosshair.h";
using namespace sf;
using namespace std;

Crosshair::Crosshair()
{
	texture.loadFromFile("crosshair.png");
	crosshairSprite.setTexture(texture);
	crosshairSprite.setOrigin(64, 64);
	crosshairSprite.setScale(0.4, 0.4);
	crosshairSprite.setPosition(400, 300);
}



