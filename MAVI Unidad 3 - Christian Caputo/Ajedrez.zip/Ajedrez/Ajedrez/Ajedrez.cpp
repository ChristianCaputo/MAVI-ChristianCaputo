#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture textureW;
Texture textureB;

int spritesPos[5][6];
Sprite sprites[5][6];

float xPosition;
float yPosition;

int main()
{
	textureW.loadFromFile("chessw.png");
	textureB.loadFromFile("chessb.png");
	xPosition = 0;
	yPosition = 0;
	int casillero = 0;

	for (int i = 0; i < 5; i++)	// matriz de posiciones de tablero
	{
		for (int j = 0; j < 6; j++)
		{
			spritesPos[i][j] = casillero;
			casillero++;
		}
	}

	for (int i = 0; i < 5; i++)
	{

		if (i % 2 == 0)
		{
			xPosition = 0;
		}
		else if (i % 2 != 0)
		{
			xPosition = 128;
		}

		for (int j = 0; j < 6; j++)		// asignacion de textura y posicion de cada elemento del tablero
		{
			if (spritesPos[i][j] % 2 == 0)
			{
				sprites[i][j].setTexture(textureW);
				sprites[i][j].setPosition(xPosition, yPosition);
				xPosition += 128;
			}
			else
			{
				sprites[i][j].setTexture(textureB);
				sprites[i][j].setPosition(xPosition, yPosition);
				xPosition += 128;
			}
		}
		yPosition += 128;
	}

	sf::RenderWindow App(sf::VideoMode(800, 600), "Ajedrez");

	while (App.isOpen())
	{
		App.clear();

		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 6; j++)
			{
				App.draw(sprites[i][j]);
			}
		}

		App.display();
	}

	return 0;

}