#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture imagen;
Sprite sprite;

int main()
{
	imagen.loadFromFile("fondo.jpg");
	sprite.setTexture(imagen);
	sprite.setScale(0.781, 0.781);

	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Ventana Fondo");

	while (App.isOpen())
	{
		App.clear();

		App.draw(sprite);

		App.display();
	}

	return 0;
}