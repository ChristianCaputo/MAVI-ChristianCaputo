#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main()
{
	sf::RenderWindow win(sf::VideoMode(800, 600), "Fast & Furious");
	sf::Vector2f posicionInicial(10.0f, 300.0f);
	float Vinicial = 4.0f;
	float Vfinal = 20.0f;

	while (win.isOpen())
	{
		sf::Event event;
		while (win.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				win.close();
		}

		float deltaTime = 1.0f / 60.0f;
		posicionInicial.x += Vinicial * deltaTime;
		if (posicionInicial.x > 800)
		{
			posicionInicial.x = 10.0f;
			Vinicial += 2.0f;
		}
		if (Vinicial > Vfinal)
		{
			Vinicial = 0;
		}

		win.clear();
		sf::CircleShape ball(20.0f);
		ball.setPosition(posicionInicial);
		ball.setFillColor(sf::Color::Red);
		win.draw(ball);
		win.display();
	}
	
	return 0;
}