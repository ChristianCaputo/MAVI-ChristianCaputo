#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main()
{
	sf::RenderWindow window(sf::VideoMode(800, 600), "Space");
	sf::Vector2f posicion(400.0f, 300.0f);
	sf::Vector2f velocidad(0.0f, 0.0f);
	float aceleracionX = 0.0f;
	float aceleracionY = 0.0f;
	float deltaTime = 0.1f / 30.0f;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) 
		{
			aceleracionX = -3.0f;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) 
		{
			aceleracionX = 3.0f;
		}
		else 
		{
			aceleracionX = 0.0f;
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) 
		{
			aceleracionY = -3.0f;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) 
		{
			aceleracionY = 3.0f;
		}
		else 
		{
			aceleracionY = 0.0f;
		}

		velocidad.x += aceleracionX * deltaTime;
		velocidad.y += aceleracionY * deltaTime;
		posicion += velocidad * deltaTime;

		window.clear();
		sf::CircleShape ball(30.0f);
		ball.setPosition(posicion);
		ball.setFillColor(sf::Color::Blue);
		window.draw(ball);
		window.display();
	}
	return 0;
}
