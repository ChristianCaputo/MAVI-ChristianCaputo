#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main()
{
	sf::RenderWindow window(sf::VideoMode(800, 600), "Space");
	sf::Vector2f posicion(400.0f, 15.0f);
	float velocidad = 0.0f;
	float aceleracionY = 20.0f;
	float deltaTime = 0.1f / 30.0f;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}
		if (Keyboard::isKeyPressed(Keyboard::Escape))
			window.close();

		if (posicion.y > 540)
		{
			velocidad = -90.0f;
			aceleracionY += 15.0f;
		}

		velocidad += aceleracionY * deltaTime;
		posicion.y += velocidad * deltaTime;

		window.clear();
		sf::CircleShape ball(30.0f);
		ball.setPosition(posicion);
		ball.setFillColor(sf::Color::Magenta);
		window.draw(ball);
		window.display();
	}

	return 0;
}