#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Crosshair
{
	private:
		Texture crossText;
		Sprite crossSprite;

	public:
		Crosshair();
		void Pose(float x, float y);
		void Draw(RenderWindow* _wnd);
};
