#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "GameManager.h";
#include "Crosshair.h";
using namespace sf;

class Game
{
	private:
		RenderWindow* wnd;
		GameManager* gameMgr;
		Crosshair* crosshair;
		void ProcessEvents();
		void Update();
		void Draw();
		void Shoot();
		sf::Font font;
		sf::Text textPuntaje;
		sf::Text textPuntos;
		int points;

	public:
		Game();
		~Game(void);
		void Go();

};