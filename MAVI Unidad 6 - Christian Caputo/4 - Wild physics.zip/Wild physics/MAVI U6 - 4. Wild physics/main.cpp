#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "Game.h";
using namespace sf;

int main()
{
	srand(time(NULL));
	Game game;
	game.Go();
	return 0;
}