#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "Crosshair.h"
using namespace sf;

Crosshair::Crosshair()
{
	crossText.loadFromFile("crosshair.png");
	crossSprite.setTexture(crossText);
	crossSprite.setOrigin(crossText.getSize().x/2.0f, crossText.getSize().y / 2.0f);
}

void Crosshair::Pose(float x, float y)
{
	crossSprite.setPosition(x, y);
}

void Crosshair::Draw(RenderWindow* _wnd)
{
	_wnd->draw(crossSprite);
}

