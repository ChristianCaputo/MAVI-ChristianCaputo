#pragma once
#include <SFML/Graphics.hpp>
#include <ctime>
using namespace sf;

class Object
{
	private:
		sf::Clock clock;
		void Throw();
		Texture textureBalloon;
		Sprite spriteBalloon;
		Texture textureSplash;
		Sprite spriteSplash;
		bool active;
		bool splash;
		float deltaTime;
		sf::Vector2f velocity;
		sf::Vector2f position;
		float accelerationY;

	public:
		Object();
		void Appear();
		void Update();
		void Draw(RenderWindow* wnd);
		bool Aim(float x, float y);
		bool isActive();
		void Dissapear();
		void Splash(Vector2i pos);
};