#include <SFML/Window.hpp>
#include <ctime>
#include "GameManager.h";
#include "Object.h";
using namespace sf;

GameManager::GameManager() {

	for (int i = 0; i < 10; i++) {

		objects[i] = new Object();
	}
	time = 0.3f;
}

void GameManager::Update() {

	if ((clock.getElapsedTime().asSeconds() > time))
	{
		int random = rand() % 10 + 0;
		int indice = round(random);
		if(!objects[indice]->isActive())
			objects[indice]->Appear();
		clock.restart();
	}
	
	for (int i = 0; i < 10; i++) {

		if(objects[i]->isActive()){
			objects[i]->Update();
		}
	}
}

void GameManager::Draw(RenderWindow* wnd) {

	for (int i = 0; i < 10; i++) {

		objects[i]->Draw(wnd);
	}
}