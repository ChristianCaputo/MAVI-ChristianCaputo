#include <SFML/Window.hpp>
#include <ctime>
#include "Object.h";
using namespace sf;

Object::Object(){

	textureBalloon.loadFromFile("water_balloon_red.png");
	textureSplash.loadFromFile("splash.png");
	spriteBalloon.setTexture(textureBalloon);
	spriteSplash.setTexture(textureSplash);
	spriteBalloon.setOrigin(textureBalloon.getSize().x / 2.0f, textureBalloon.getSize().y / 2.0f);
	spriteSplash.setOrigin(textureSplash.getSize().x / 2.0f, textureSplash.getSize().y / 2.0f);
	spriteSplash.setScale(0.00001, 0.00001);
	active = false;
	splash = false;
	deltaTime = 0.1f / 30.0f;
	Dissapear();
}

void Object::Appear() {

	active = true;
	spriteBalloon.setScale(1, 1);
	Throw();
	clock.restart();
}

void Object::Update(){

	velocity.y += accelerationY * deltaTime;
	position += velocity * deltaTime;
	spriteBalloon.setPosition(position);
	spriteBalloon.rotate(15 * deltaTime);

	if (position.y < position.y - 10){
		accelerationY = 40.0f;
	}
	if ((position.x < -10) || (position.x > 810)) {
		Dissapear();
	}

	if ((splash==true) && (clock.getElapsedTime().asSeconds() > 0.05f)) {
		spriteSplash.setScale(0.0001f, 0.00001f);
		splash = false;
	}
}

void Object::Throw(){

	// f�sica de lanzamiento
	int random1 = rand() % 10 + 1;
	if (random1 < 5) {

		// lado izquierdo
		position.x = 20;
		int random = rand() % 10 + 1;
		if (random < 6){
		velocity.x = 70.0f;
		}
		else {
			velocity.x = 50.0f;
		}
	}
	else {
		// lado derecho 
		position.x = 780;
		int random = rand() % 10 + 1;
		if (random < 6) {
			velocity.x = 70.0f;
		}
		else {
			velocity.x = 50.0f;
		}
		velocity.x = -70.0f;
	}

	int random = rand() % 10 + 1;
	if (random < 5) {
		// posicion superior de lanzamiento
		velocity.y = -55.0f;
		position.y = 200;
		accelerationY = 10.0f;
	}
	else {
		// posicion inferior de lanzamiento
		velocity.y = -85.0f;
		accelerationY = 10.0f;
		position.y = 550;
	}
};

bool Object::Aim(float x, float y) {

	FloatRect bounds = spriteBalloon.getGlobalBounds();
	if (bounds.contains(x,y))
	{
		return true;
	}
}

void Object::Splash(sf::Vector2i pos) {

	clock.restart();
	spriteSplash.setScale(1.0, 1.0);
	spriteSplash.setPosition(static_cast<float>(pos.x), static_cast<float>(pos.y));
	splash = true;
}

void Object::Dissapear()
{
	spriteBalloon.setScale(0.00001f, 0.00001f);
	active = false;
}

void Object::Draw(RenderWindow* wnd){
	
	wnd->draw(spriteSplash);
	wnd->draw(spriteBalloon);
}

bool Object::isActive(){

	return active;
}

