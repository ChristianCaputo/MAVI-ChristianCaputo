#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "Game.h";
using namespace sf;

Game::Game()
{
	wnd = new RenderWindow(sf::VideoMode(800, 600), "Wild Physics");
	wnd->setMouseCursorVisible(false);
	gameMgr = new GameManager();
	crosshair = new Crosshair();
	points = 0;

	font.loadFromFile("Water Galon.ttf");
	textPuntaje.setFont(font);
	textPuntaje.setCharacterSize(20);
	textPuntaje.setPosition(340, 560);
	textPuntaje.setFillColor(sf::Color::Blue);
	textPuntaje.setString("PUNTAJE:");
	textPuntaje.setOutlineColor(sf::Color::Black);
	textPuntaje.setOutlineThickness(1.0f);

	textPuntos.setFont(font);
	textPuntos.setCharacterSize(25);
	textPuntos.setPosition(440, 555);
	textPuntos.setFillColor(sf::Color::Yellow);
	textPuntos.setOutlineColor(sf::Color::Black);
	textPuntos.setOutlineThickness(1.5f);
}

void Game::Go(){

	while (wnd->isOpen())
	{
		ProcessEvents();
		Update();
		Draw();
	}
}

void Game::ProcessEvents() {

	Event evt;
	while (wnd->pollEvent(evt)) {
		switch (evt.type){
		
		case sf::Event::Closed:
			wnd->close();
			break;
		case sf::Event::MouseButtonPressed:
			if (evt.mouseButton.button == Mouse::Button::Left)
			{
				Shoot();
			}
			break;
		}
	}
}

void Game::Update() {

	Vector2i mousePos = Mouse::getPosition(*wnd);
	crosshair->Pose(mousePos.x, mousePos.y);

	gameMgr->Update();
	textPuntos.setString(std::to_string(points));
}

void Game::Draw() {

	wnd->clear(Color::Cyan);
	gameMgr->Draw(wnd);
	crosshair->Draw(wnd);
	wnd->draw(textPuntaje);
	wnd->draw(textPuntos);
	wnd->display();
}

void Game::Shoot() {

	Vector2i posicion = Mouse::getPosition(*wnd);
	for (int i = 0; i < 10; i++)
	{
		if (gameMgr->objects[i]->Aim(posicion.x, posicion.y))
		{
			gameMgr->objects[i]->Dissapear();
			gameMgr->objects[i]->Splash(posicion);
			points += 10;
		}
	}
}

Game::~Game(){

	delete gameMgr;
	delete crosshair;
	delete wnd;
}

