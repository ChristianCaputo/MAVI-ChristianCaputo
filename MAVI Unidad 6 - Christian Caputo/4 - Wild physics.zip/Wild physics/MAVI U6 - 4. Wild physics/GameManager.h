#pragma once
#include "Object.h";
#include <ctime>

class GameManager
{
	private:
		int destroyedObjects;
		Clock clock;
		float time;

	public:
		Object* objects[10];
		GameManager();
		void Update();
		void Draw(RenderWindow* wnd);
};